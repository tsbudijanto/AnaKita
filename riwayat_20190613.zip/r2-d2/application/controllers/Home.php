<?php defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {
	public function index(){
        //$this->session->sess_destroy();
        if($this->input->get('r2d2')){
            $this->session->set_userdata('r2d2', 'true');
        }
        if($this->input->post('user')){
            $email  = $this->input->post('user'); 
            $pass   = $this->input->post('pass'); 

            $sql     = "
                        SELECT * 
                        FROM users 
                        WHERE 
                            email = '$email'
                            AND password = '$pass'
                        ";
            $db_user = $this->db->query($sql)->row();
            $user       = $db_user->username;
            $id         = $db_user->id;
            $admin      = intval($db_user->active);

            $this->session->set_userdata('mail', $email);
            $this->session->set_userdata('user', $user);
            $this->session->set_userdata('user_id', $id);
            $this->session->set_userdata('administrator', $admin);
        }
        //echo "user : ".$this->session->userdata('user');
        if($this->session->userdata('user')){
            $this->load->view('home');
        }else{
            $this->load->view('login');         
        }
    }
}
