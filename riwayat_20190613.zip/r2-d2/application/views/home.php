<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<?php $this->load->view('inc/home_header_head'); ?>
<?php $this->load->view('inc/home_header_css'); ?>
<?php $this->load->view('inc/home_header_meta_title'); ?>
<?php $this->load->view('inc/home_header_body'); ?>




<div class="wrapper">

	<?php $this->load->view('inc/home_menu'); ?>


  <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <!-- Main content -->
        <iframe src="<?=base_url()?>../?<?//='user='.$this->session->userdata('mail').'&pass='.$this->input->post('pass')?>" id="r2d2-page" name="r2d2-page" width="100%" height="800px">
            Loading...
        </iframe>
  </div>
  <!-- /.content-wrapper -->

</div>

<?php $this->load->view('inc/home_footer_js'); ?>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?=base_url()?>js/pages/dashboard2.js"></script>

<?php $this->load->view('inc/home_footer_body'); ?>
<?if(false){?>
<script type="text/javascript">

      //var x = document.getElementById("r2d2-page").contentWindow.document.getElementById("view_lat");
      var x = document.getElementById("view_lat");
      //x.innerHTML = "TEST Latitude: " ;
      function getLocation() {
          if (navigator.geolocation) {
              navigator.geolocation.getCurrentPosition(showPosition);
          } else {
              x.innerHTML = "Geolocation is not supported by this browser.";
          }
      }
      function showPosition(position) {
          x.innerHTML = "Latitude: " + position.coords.latitude +
          "<br>Longitude: " + position.coords.longitude;
      }
    $( document ).ready(function() {
      getLocation();
      //$( "#get_lat" ).click(getLat());    
        //alert('cek lokasi');
        //getLocation();
    });  

</script>
<?}?>