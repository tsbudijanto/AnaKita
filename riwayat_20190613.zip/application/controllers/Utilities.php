<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Utilities extends CI_Controller {

	public function index(){
		//nothing
	}

	function utilities_database(){

		$data['title'] = 'Survey - Data Foto/Denah';


		$sql 				= "SELECT * FROM `survey01_lokasi`";
        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 
		$this->load->view('visual_produk',$data);
	}
}

