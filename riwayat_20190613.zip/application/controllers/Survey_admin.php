<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Survey_admin extends CI_Controller {

	public function index(){
		//nothing
	}

	function download(){

		$data['title'] = 'Survey Admin - Download';


		$sql 				= "SELECT * FROM `survey01_lokasi`";
        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 
		$this->load->view('survey_admin_download',$data);
	}
	function upload(){

		$data['title'] = 'Survey Admin - Upload';


		$sql 				= "SELECT * FROM `survey01_lokasi`";
        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 
		$this->load->view('survey_admin_upload',$data);
	}
	function export(){

		$data['title'] = 'Survey Admin - Upload';


		$sql 				= "SELECT * FROM `survey01_lokasi`";
        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 
		$this->load->view('survey_admin_export',$data);
	}

}

