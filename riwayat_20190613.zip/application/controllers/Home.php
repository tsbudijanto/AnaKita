<?php defined('BASEPATH') OR exit('No direct script access allowed');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

class home extends CI_Controller {
	public function index(){
        if($this->input->get('r2d2')){
            $this->session->set_userdata('r2d2', 'true');
        }
        if($this->input->post('user')){
        	$email 	= $this->input->post('user'); 
        	$pass 	= $this->input->post('pass'); 

        	$sql	 = "
        				SELECT * 
        				FROM users 
        				WHERE 
        					username = '$email'
        					AND password = '$pass'
        				";

        	$db_user    = $this->db->query($sql)->row();
			if(isset($db_user))
			{
				$user 		= $db_user->username;
				$id         = $db_user->id;
				$admin      = intval($db_user->active);
	
				$this->session->set_userdata('mail', $email);
				$this->session->set_userdata('user', $user);
				$this->session->set_userdata('user_id', $id);
				$this->session->set_userdata('administrator', $admin);
				 //echo $this->session->userdata('user') ; exit ;
    		}
			else {     ?>
 				 
              <div class="form-horizontal box-body">
                <center>
                    <h1>
                        <font color="red">
                            Gagal, User ID dan Password tidak sama
                        </font>
                    </h1>
                </center>
            </div>

	<?		}
		}
        //echo "user : ".$this->session->userdata('user');
		//exit;
		if($this->session->userdata('user')){
            if($this->input->get('group_id')){
                $group_id           = $this->input->get('group_id');
                $sql                = "SELECT * FROM `survey01_lokasi` WHERE group_id = '$group_id' ";
                $data_db            = $this->db->query($sql);
                $data['data_db']    = $data_db; 

                $sql                = "SELECT * FROM `survey08_pembanding` WHERE group_id = '$group_id' ";
                $data_dbp           = $this->db->query($sql)->row();
        		$id_yayasan			= $data_dbp->id_data;
				$group_id			= $data_dbp->group_id;
		        $this->session->set_userdata('id_yayasan', $id_yayasan);
				$this->session->set_userdata('group_id', $group_id);
				//echo $this->session->userdata('id_yayasan');
				//exit;
            }else{
                $sql_where_g = "";
                $sql_where_u = "";
                if(!$this->session->userdata('administrator') == '1'){
                    $user_id        = $this->session->userdata('user_id');
                    $sql_where_g        = "WHERE id IN (SELECT users_groups.group_id FROM users_groups WHERE users_groups.user_id = '$user_id')"; 
                    $sql_where_u        = "WHERE id = '$user_id'" ;
                }

                $sql                    = " SELECT *,
                                                (SELECT COUNT(*) FROM survey01_lokasi WHERE groups.id = survey01_lokasi.group_id ) as group_all,
                                                (SELECT COUNT(*) FROM survey01_lokasi WHERE groups.id = survey01_lokasi.group_id AND survey01_lokasi.status = 3) as group_done
                                            FROM `groups` 
                                            $sql_where_g 
                                            ";
                $data_db                = $this->db->query($sql);
                $data['ds_goal']        = $data_db; 

                $sql                = "SELECT * FROM `survey08_pembanding` INNER JOIN `users_groups` ON  `survey08_pembanding`.`group_id` =  `users_groups`.`group_id`
										WHERE `users_groups`.`user_id` = '" . $this->session->userdata('user_id') . "'";
				//echo $sql;
				//exit;
				$data_dbp           = $this->db->query($sql)->row();

				if(!empty($data_dbp)){
					$id_yayasan			= $data_dbp->id_data;
					$nm_yayasan			= $data_dbp->rangka;
					$group_id			= $data_dbp->group_id;
					$this->session->set_userdata('id_yayasan', $id_yayasan);
					$this->session->set_userdata('nama_yayasan', $nm_yayasan);
					$this->session->set_userdata('group_id', $group_id);
				}
				//echo $this->session->userdata('id_yayasan') . ", group = " . $this->session->userdata('group_id');
				//exit;
             }

			//if (isset($_POST['daftar'])) {
				$this->load->view('home', $data);
			//}

		}else{
			$this->load->view('login');			
		}
	}
	
}
