<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lpr_hbu extends CI_Controller {

	public function index(){

		$sql_where 	= "";
		$sql_and 	= "";
		if(!$this->session->userdata('administrator') == '1'){
			$user_id 		= $this->session->userdata('user_id');
			$sql_where 		= "WHERE group_id IN (SELECT users_groups.group_id FROM users_groups WHERE users_groups.user_id = '$user_id')"; 
			$sql_and 		= "AND group_id IN (SELECT users_groups.group_id FROM users_groups WHERE users_groups.user_id = '$user_id')"; 
		}


		$lokasi 		= $this->input->get('lokasi');
		$sql 				= "SELECT * FROM `survey01_lokasi` $sql_where";
		//echo $sql ;exit;

        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 


		$this->load->view('lpr_hbu',$data);

	}

}

