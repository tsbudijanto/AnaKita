<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Survey extends CI_Controller {

	public function index(){
		//nothing
	}

	function users(){

		$data['title'] = 'Survey Admin - Download';


		$sql 				= "SELECT * FROM `survey01_lokasi`";
        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 
		$this->load->view('survey_admin_download',$data);
	}

	function admin_user(){

		$data['title'] = 'Survey Admin - Download';


		$sql 				= "SELECT * FROM `survey01_lokasi`";
        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 
		$this->load->view('survey_admin_download',$data);
	}
	function admin_groups(){

		$data['title'] = 'Survey Admin - Upload';


		$sql 				= "SELECT * FROM `survey01_lokasi`";
        $data_db 			= $this->db->query($sql);
        $data['data_db'] 	= $data_db; 
		$this->load->view('survey_admin_upload',$data);
	}
}

